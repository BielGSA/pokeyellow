MtMoonB2FScript_ApplyPikachuMovementData:
	ld a, [wPikachuSpawnStateFlags]
	bit BIT_PIKACHU_SPAWN_STARTER, a
	ret z
	ld a, [wWalkBikeSurfState]
	and a
	ret nz

	push hl
	push bc
	callfar GetPikachuFacingDirectionAndReturnToE
	pop bc
	pop hl
	ld a, b
	cp e
	ret nz

	push hl
	ld a, [wUpdateSpritesEnabled]
	push af
	ld a, $ff
	ld [wUpdateSpritesEnabled], a
	callfar LoadPikachuShadowIntoVRAM
	pop af
	ld [wUpdateSpritesEnabled], a
	pop hl
	call ApplyPikachuMovementData
	ret
